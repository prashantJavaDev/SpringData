import java.util.concurrent.CountDownLatch;

public class Service implements Runnable{
	private String name;
	private long timeTostart;
	CountDownLatch latch;

	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try{
			Thread.sleep(timeTostart);
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println(name+" is Up");
		latch.countDown();
	}


	public Service(String name, long timeTostart, CountDownLatch latch) {
		super();
		this.name = name;
		this.timeTostart = timeTostart;
		this.latch = latch;
	}

}
