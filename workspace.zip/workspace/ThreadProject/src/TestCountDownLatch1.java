import java.util.concurrent.CountDownLatch;

public class TestCountDownLatch1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CountDownLatch latch=new CountDownLatch(3);
		new Thread(new Service("Validator", 1000, latch)).start();
		new Thread(new Service("startter", 1000, latch)).start();
		new Thread(new Service("services", 1000, latch)).start();
		try{
			latch.await();
			System.out.println("All services Up");
		}catch(Exception e){
			
		}
	}

}
