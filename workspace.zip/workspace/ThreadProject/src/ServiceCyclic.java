import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;

public class ServiceCyclic implements Runnable{
	private String name;
	private long timeTostart;
	CyclicBarrier barrier;

	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		try{
			System.out.println(name+" is  starting");
			barrier.await();
			Thread.sleep(timeTostart);
		}catch(Exception e){
			e.printStackTrace();
		}
		System.out.println(name+" is Up");
	}


	public ServiceCyclic(String name, long timeTostart, CyclicBarrier barrier) {
		super();
		this.name = name;
		this.timeTostart = timeTostart;
		this.barrier = barrier;
	}

}
