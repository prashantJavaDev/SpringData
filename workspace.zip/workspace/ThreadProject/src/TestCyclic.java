import java.util.concurrent.CountDownLatch;
import java.util.concurrent.CyclicBarrier;

public class TestCyclic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CyclicBarrier barrier=new CyclicBarrier(3);
		new Thread(new ServiceCyclic("Validator", 1000, barrier)).start();
		new Thread(new ServiceCyclic("startter", 1000, barrier)).start();
		new Thread(new ServiceCyclic("services", 1000, barrier)).start();
		try{
			barrier.await();
			barrier.reset();
			System.out.println("All services Up");
		}catch(Exception e){
			
		}
	}

}
