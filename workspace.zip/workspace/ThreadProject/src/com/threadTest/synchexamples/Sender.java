package com.threadTest.synchexamples;

public class Sender {
public synchronized void send(String msg){
	for(int i=0;i<10;i++){
	try{
		Thread.sleep(1000);
	}catch(Exception e){
		e.printStackTrace();
	}
	System.out.println("Hi Messange sent " + msg+" "+i);
	}
}
}
