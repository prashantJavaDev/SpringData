package com.threadTest.synchexamples;

public class SenderThread extends Thread{
private String msg;
private Sender sender;
public SenderThread(String msg, Sender sender) {
	super();
	this.msg = msg;
	this.sender = sender;
}
public void run(){
	sender.send(msg);	
}
}
