package com.threadTest.synchexamples;

public class SyncDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Sender s=new Sender();
		SenderThread t1=new SenderThread("kim", s);
		SenderThread t2=new SenderThread("Prashu", s);
		t1.start();
		t2.start();
	}

}
