package com.threadTest.deadlockExample;

public class Sender {
	public void send( ){

		System.out.println("Im in sender");
		
	}
}
