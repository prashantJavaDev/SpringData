package com.threadTest.deadlockExample;

public class DedlockTest2 {
	public static void main(String s[]){
	Sender d=new Sender();
	Reciever r=new Reciever();
	SenderThread st=new SenderThread(d, r);
	RecieverThread rt=new RecieverThread(d, r);
	st.start();
	rt.start();
	}
	
}
