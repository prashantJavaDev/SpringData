package com.threadTest.deadlockExample;

public class Reciever {
public  void recive( ){
	System.out.println("Im in reciver");
}
}
