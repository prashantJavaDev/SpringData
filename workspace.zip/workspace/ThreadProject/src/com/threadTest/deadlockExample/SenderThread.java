package com.threadTest.deadlockExample;

public class SenderThread extends Thread{
private Sender s;
private Reciever r;

	@Override
	public void run() {
		// TODO Auto-generated method stub
		synchronized(s){
			  System.out.println("Thread 1: Holding lock 1...");
			  s.send();
			  try{Thread.sleep(10);}
			  catch(InterruptedException e){}
			  System.out.println("Thread 1: waiting lock 2...");
			  synchronized(r){
				  System.out.println("Thread 1: Holding lock 1 and 2...");
			  }
		}
	}

	public SenderThread(Sender s, Reciever r) {
		super();
		this.s = s;
		this.r = r;
	}

}
