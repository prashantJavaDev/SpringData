package com.threadTest.semaphore;

import java.util.concurrent.Executor;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.stream.IntStream;

public class SemaphoreExample {

	public static void main(String[] args) throws InterruptedException{
		// TODO Auto-generated method stub
		ExecutorService e=Executors.newFixedThreadPool(50);
		IntStream.range(0,1000).forEach((i)->{
			System.out.println("inside for exh"+i);
			e.execute(new Task());
		});
		e.shutdown();
		e.awaitTermination(1, TimeUnit.MINUTES);
	}
public static class Task implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		try{
			System.out.println("Dataaa=======");
			Thread.sleep(1);
		}catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
}
}
