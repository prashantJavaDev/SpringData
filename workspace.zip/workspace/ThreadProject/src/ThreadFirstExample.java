
public class ThreadFirstExample extends Thread{
 public void run(){
	 for(int i=0;i<=10;i++)
	 System.out.println("I m in Class Theead 1 counter"+ i);
	 
 }
	public static void main(String[] args) throws InterruptedException{
		// TODO Auto-generated method stub
		ThreadFirstExample t1=new ThreadFirstExample();
		t1.start();
		t1.join();
		for(int i=0;i<=10;i++)
			System.out.println("I m in main Theead 2 counter"+ i);
	}

}
