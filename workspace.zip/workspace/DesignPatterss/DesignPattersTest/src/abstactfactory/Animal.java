package abstactfactory;

public interface Animal {
	public String behaviour();
}
