package abstactfactory;

public class PetAnimal implements Animal {

	@Override
	public String behaviour() {
		// TODO Auto-generated method stub
		return "Good";
	}

}
