package abstactfactory;

public class AnimalFactoryProvider {
public static AnimalFactory getFactory(int i){
	if(i==1)
		return  new WildAnimalFactory();
	if(i==2)
		return new PetAnimalFactory();
	
	throw new RuntimeException("invalid choice");
}
}
