package abstactfactory;

public class WildAnimalFactory extends AnimalFactory {

	@Override
	public Animal getAnimal() {
		// TODO Auto-generated method stub
		return new WildAnimal();
	}

}
