package abstactfactory;

public class PetAnimalFactory extends AnimalFactory {

	@Override
	public Animal getAnimal() {
		// TODO Auto-generated method stub
		return new PetAnimal();
	}

}
