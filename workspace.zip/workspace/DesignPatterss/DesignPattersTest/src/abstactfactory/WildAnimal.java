package abstactfactory;

public class WildAnimal implements Animal {

	@Override
	public String behaviour() {
		// TODO Auto-generated method stub
		return "GoodButWIld";
	}

}
