package abstactfactory;

public class AbstactFatoryTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(AnimalFactoryProvider.getFactory(1).getAnimal().behaviour());
		System.out.println(AnimalFactoryProvider.getFactory(2).getAnimal().behaviour());
		System.out.println(AnimalFactoryProvider.getFactory(0).getAnimal().behaviour());
	}

}
