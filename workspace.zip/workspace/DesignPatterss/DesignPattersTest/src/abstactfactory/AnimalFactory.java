package abstactfactory;

public abstract class AnimalFactory {
public abstract Animal getAnimal();

}
