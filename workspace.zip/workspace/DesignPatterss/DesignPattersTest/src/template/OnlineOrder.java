package template;

public class OnlineOrder extends OrderTemplate{

	@Override
	public void doSelect() {
		// TODO Auto-generated method stub
		System.out.println("online doselct");
		
	}

	@Override
	public void doPayment() {
		// TODO Auto-generated method stub
		System.out.println("online dopayment");
		
	}

	@Override
	public void doCheckout() {
		// TODO Auto-generated method stub
		System.out.println("online doCheckout");
		
	}

	@Override
	public void doDelivery() {
		// TODO Auto-generated method stub
		System.out.println("online doDelivery");
		
	}

}
