package template;

public class OfflineOrder extends OrderTemplate{

	@Override
	public void doSelect() {
		// TODO Auto-generated method stub
		System.out.println("offline doSelect");
		
	}

	@Override
	public void doPayment() {
		// TODO Auto-generated method stub
		System.out.println("offline doPayment");
		
	}

	@Override
	public void doCheckout() {
		// TODO Auto-generated method stub
		System.out.println("offline doCheckout");
		
	}

	@Override
	public void doDelivery() {
		// TODO Auto-generated method stub
		System.out.println("offline doDelivery");
		
	}

}
