package template;

public class OrderTemplateTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		OrderTemplate ord=new OnlineOrder();
		ord.doProcess();
		OrderTemplate ord1=new OfflineOrder();
		ord1.doProcess();
	}

}
