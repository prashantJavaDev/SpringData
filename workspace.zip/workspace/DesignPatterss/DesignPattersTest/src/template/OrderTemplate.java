package template;

public abstract class OrderTemplate {

	public abstract void doSelect();

	public abstract void doPayment();

	public abstract void doCheckout();

	public abstract void doDelivery();

	public void doProcess() {
		doSelect();
		doCheckout();
		doPayment();
		doDelivery();
	}
}
