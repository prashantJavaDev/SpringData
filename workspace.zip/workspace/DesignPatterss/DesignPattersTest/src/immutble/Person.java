package immutble;

public final class Person {
private int pId;
private String name;
private Address add;
public Person(int pId, String name, Address add) {
	super();
	this.pId = pId;
	this.name = name;
	this.add = add;
}
public int getpId() {
	return pId;
}
public String getName() {
	return name;
}
public Address getAdd() {
	Address temp=new Address();
	temp.setStreet1(add.getStreet1());
	temp.setStreet2(add.getStreet2());
	temp.setStreet3(add.getStreet3());
	return temp;
//	return add;
}
@Override
public String toString() {
	return "Person [pId=" + pId + ", name=" + name + ", add=" + add + "]";
}

}
