package immutble;

public class ImmutableTest {
public static void main(String a[]){
	Person p=new Person(1, "datd", new Address("str1","str2","str3"));
	System.out.println(p);
	p.getAdd().setStreet1("pakistan");
	System.out.println(p);
	
}
}
