package builder;

public class Computer {
	private String ram;
	private String hdd;
	private String processor;
	
 public String getRam() {
		return ram;
	}

	public void setRam(String ram) {
		this.ram = ram;
	}

	public String getHdd() {
		return hdd;
	}

	public void setHdd(String hdd) {
		this.hdd = hdd;
	}

	public String getProcessor() {
		return processor;
	}

	public void setProcessor(String processor) {
		this.processor = processor;
	}
	

public Computer(String ram, String hdd, String processor) {
		super();
		this.ram = ram;
		this.hdd = hdd;
		this.processor = processor;
	}

public Computer(ComputerBuilder com){
	 this.ram=com.getRam();
	 this.hdd=com.getHdd();
	 this.processor=com.getProcessor();
 }

@Override
public String toString() {
	return "Computer [ram=" + ram + ", hdd=" + hdd + ", processor=" + processor + "]";
}

}
