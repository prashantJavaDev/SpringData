package builder;

public class ComputerBuilder {

	private String ram;
	private String hdd;
	private String processor;
	
	
	public ComputerBuilder setRam(String ram){
		this.ram=ram;
		return this;
	}
	public ComputerBuilder setHdd(String hdd){
		this.hdd=hdd;
		return this;
	}
	public ComputerBuilder setProcessor(String processor){
		this.processor=processor;
		return this;
	}
	public Computer build(){
		return new Computer(this);
	}
	public String getRam() {
		return ram;
	}
	public String getHdd() {
		return hdd;
	}
	public String getProcessor() {
		return processor;
	}
	
}
