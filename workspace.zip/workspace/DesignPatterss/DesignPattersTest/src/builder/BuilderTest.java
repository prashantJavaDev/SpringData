package builder;

public class BuilderTest {
	public static void main(String a[]){
		Computer b=new ComputerBuilder().setRam("8").setHdd("1TB").setProcessor("i10").build();
		System.out.println(b);
	}

}
