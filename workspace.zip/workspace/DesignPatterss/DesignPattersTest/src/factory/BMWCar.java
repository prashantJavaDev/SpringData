package factory;

public class BMWCar implements Car {

	@Override
	public String sound() {
		// TODO Auto-generated method stub
		return "BMW Car Sound";
	}

}
