package factory;

public interface Car {
	String sound();
}
