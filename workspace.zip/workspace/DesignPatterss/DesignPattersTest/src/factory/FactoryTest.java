package factory;

public class FactoryTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Car c1=CarFactory.getCar("T");
	Car c2=CarFactory.getCar("B");
	System.out.println(c1.sound());
	System.out.println(c2.sound());
	Car c3=CarFactory.getCar("W");
	System.out.println(c3.sound());

	}

}
