package factory;

public class CarFactory {
public static Car getCar(String choice){
	if(choice.equalsIgnoreCase("T"))
		return new TataCar();
	if(choice.equalsIgnoreCase("B"))
		return new BMWCar();
	
	throw new RuntimeException("NO CAR Available"); 
}
}
