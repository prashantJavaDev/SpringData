package factory;

public class TataCar implements Car {

	@Override
	public String sound() {
		// TODO Auto-generated method stub
		return "TATA Car Sound";
	}

}
