package prototype;

public class PrototypeTest {
	
	public static void main(String a[]){
		
		Employee emp=new Employee("PK", 10);
		//Deep cloning
		Employee emp1=(Employee)emp.clone();
		
		//shalow clonong
		Employee emp2=emp;
		
		System.out.println("Beforee-------------");
		System.out.println(emp);
		System.out.println(emp1);
		System.out.println(emp2);
		emp.setName("RK");
		System.out.println("After-------------");
		System.out.println(emp);
		System.out.println(emp1);
		System.out.println(emp2);
		
		
	}
	

}
