package prototype;

public class Employee implements Cloneable{
	private String name;
	private long id;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Employee(String name, long id) {
		super();
		this.name = name;
		this.id = id;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	
	public Employee() {
	}
	protected Object clone(){
		Employee temp =new Employee();
		temp.setId(this.id);
		temp.setName(this.name);
		return temp;
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", id=" + id + "]";
	}
	

}
