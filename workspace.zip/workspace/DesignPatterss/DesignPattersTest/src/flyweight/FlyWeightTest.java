package flyweight;

public class FlyWeightTest {
	public static void main(String a[]){
		Pen p1=PenFactory.getPen("Black");
		Pen p2=PenFactory.getPen("Blue");
		Pen p3=PenFactory.getPen("Blue");
		Pen p4=PenFactory.getPen("Black");
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(p3);
		System.out.println(p4);
	}

}
