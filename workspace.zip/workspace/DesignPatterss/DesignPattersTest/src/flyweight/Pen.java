package flyweight;

public interface Pen {
public String color();
}
