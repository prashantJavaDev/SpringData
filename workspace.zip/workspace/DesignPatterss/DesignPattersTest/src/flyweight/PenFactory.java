package flyweight;

import java.util.HashMap;
import java.util.Map;

public class PenFactory {
	public static Map<String,Pen> map=new HashMap<>();
	public  static Pen getPen(String choice){
		String key=choice+"Pen";
		Pen p=map.get(key);
		if(p!=null)
			return p;
		
		if(choice.equalsIgnoreCase("Blue")){
			Pen bluePen=new BluePen();
			map.put(key, bluePen);
			return bluePen;
		}else if(choice.equalsIgnoreCase("Black")){
			Pen blackPen=new BlackPen();
			map.put(key, blackPen);
			return blackPen;
		}else{
			throw new RuntimeException("No Pen availalble");
		}
	}

}
