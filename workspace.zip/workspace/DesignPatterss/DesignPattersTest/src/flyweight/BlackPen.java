package flyweight;

public class BlackPen implements Pen {

	@Override
	public String color() {
		// TODO Auto-generated method stub
		return "BlackPenS";
	}

}
