package flyweight;

public class BluePen implements Pen {

	@Override
	public String color() {
		// TODO Auto-generated method stub
		return "BLuePEn";
	}

}
