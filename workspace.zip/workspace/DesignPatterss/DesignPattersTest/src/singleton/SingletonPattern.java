package singleton;

public class SingletonPattern implements Cloneable{
	
	private static SingletonPattern instance=new SingletonPattern();
	
	private SingletonPattern(){}
	
	public static SingletonPattern getInstance(){
		synchronized (SingletonPattern.class) {
			return instance;
			
		}
	}
	protected Object readResolve(){
		return instance;
	}
	
	protected Object clone(){
		return instance;
	}
}
