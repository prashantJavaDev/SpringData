package singleton;

public class SingletonTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SingletonPattern singletonPattern=SingletonPattern.getInstance();
		SingletonPattern singletonPattern1=SingletonPattern.getInstance();
		System.out.println(singletonPattern.toString());	
		System.out.println(singletonPattern1.toString());	
	}

}
