package com.java8.supplier;

import java.util.function.Supplier;

public class SupplierExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Supplier<Integer> i=()->(int) (Math.random()*100);
		System.out.println(i.get());
		System.out.println(i.get());
	}
}
