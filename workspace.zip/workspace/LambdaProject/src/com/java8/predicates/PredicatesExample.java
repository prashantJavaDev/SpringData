package com.java8.predicates;

import java.util.function.Predicate;

public class PredicatesExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Predicate<Integer> p1 = (a) -> a > 20;
		System.out.println(p1.test(30));
		Predicate<Integer> p2 = (a) -> a < 30;
		System.out.println(p1.or(p2).negate().test(30));
	}

}
