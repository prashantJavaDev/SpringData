package com.java8.predicates;

import java.util.function.DoublePredicate;
import java.util.function.IntPredicate;
import java.util.function.LongPredicate;

public class IFDPredicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IntPredicate i=(a)->a>20;
		DoublePredicate d=(a)->a>20;
		LongPredicate l=(a)->a>20;
			System.out.println(i.test(15));
			System.out.println(i.test(19));
			System.out.println(i.test(21));
	}

}
