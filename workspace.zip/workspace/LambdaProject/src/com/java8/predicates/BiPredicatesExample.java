package com.java8.predicates;

import java.util.List;
import java.util.function.BiPredicate;

import com.intface.Employee;
import com.intface.EmployeeList;

public class BiPredicatesExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> list=EmployeeList.getEmpList();
		BiPredicate<String, String> b1=(x,y)->x.equals(y);
		BiPredicate<String, Float> b2=(x,y)->x.startsWith("P") && y>10000;
		BiPredicate<List<String>, Float> b3=(x,y)->x.contains("Java") && y>5000;
		System.out.println(b1.test("Amey", "Amey"));
		System.out.println(b1.test("Amey", "Ame"));
		
		list.forEach(emp->{
			if(b2.test(emp.getName(), emp.getSalary())){
				System.out.println(emp);
			}
		});
		list.forEach(emp->{
			if(b3.test(emp.getSkills(), emp.getSalary())){
				System.out.println(emp);
			}
		});
	}

}
