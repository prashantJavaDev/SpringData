package com.java8.predicates;

import java.util.List;
import java.util.function.Predicate;

import com.intface.Employee;
import com.intface.EmployeeList;

public class PredicateWithObject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> list = EmployeeList.getEmpList();
		Predicate<Employee> p1 = (emp) -> emp.getName().startsWith("P");
		Predicate<Employee> p2 = (emp) -> emp.getEmpID() > 2;
		Predicate<Employee> p3 = (emp) -> emp.getSkills().contains("Java");
		list.forEach(e -> {
			if (p1.test(e))
				System.out.println(e.getName());
		});
		list.forEach(e -> {
			if (p2.test(e))
				System.out.println(e.getName());
		});
	list.forEach(e -> {
		if (p3.test(e))
			System.out.println(e.getName());
	});
}

}
