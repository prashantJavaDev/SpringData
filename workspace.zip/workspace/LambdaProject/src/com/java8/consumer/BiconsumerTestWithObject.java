package com.java8.consumer;

import java.util.List;
import java.util.function.BiConsumer;

import com.intface.Employee;
import com.intface.EmployeeList;

public class BiconsumerTestWithObject {
public static void main(String a[]){
	List<Employee> list=EmployeeList.getEmpList();
	BiConsumer<String,String> b1=(x,y)->{
		System.out.println("name="+x+" "+"Lastname="+y);
	};
	BiConsumer<String,Integer> b2=(x,y)->{
		System.out.println("name="+x+" "+"Id="+y);
	};
	BiConsumer<String,List<String>> b3=(x,y)->{
		System.out.println("name="+x+" "+"Skils="+y);
	};
	list.forEach(emp->{
		b1.accept(emp.getName(),emp.getLastName());
	});
	list.forEach(emp->{
		b2.accept(emp.getName(),emp.getEmpID());
	});
	list.forEach(emp->{
		b3.accept(emp.getName(),emp.getSkills());
	});
	
}
}
