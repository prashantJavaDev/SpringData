package com.java8.consumer;

import java.util.List;
import java.util.function.Consumer;

import com.intface.Employee;
import com.intface.EmployeeList;

public class ConsumerTestWithObject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> list=EmployeeList.getEmpList();
		Consumer<Employee> c1=(emp)->System.out.println("Emp Name"+emp.getName() +" Last Name"+emp.getLastName());;
		Consumer<Employee> c2=(emp)->System.out.println("Emp Salary"+emp.getSalary() +" Last Name"+emp.getLastName());;
		Consumer<Employee> c3=(emp)->System.out.println("Emp skills"+emp.getSkills() +" Last Name"+emp.getLastName());;
		Consumer<Employee> c4=(emp)->System.out.println("Emp Id"+emp.getEmpID() +" Last Name"+emp.getLastName());;
		list.forEach(c1);
		list.forEach(c2);
		list.forEach(c3);
		list.forEach(c4);
		System.out.println("--------------------------------------------------");
		list.forEach(c1.andThen(c2).andThen(c3).andThen(c4));
		System.out.println("--------------------------------------------------");
		list.forEach((emp)->{
			if(emp.getEmpID()>=2)
			{
				c1.andThen(c4).andThen(c2).accept(emp);
			}
		});
	}

}
