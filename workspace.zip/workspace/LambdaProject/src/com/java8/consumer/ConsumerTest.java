package com.java8.consumer;

import java.util.List;
import java.util.function.Consumer;

import com.intface.Employee;
import com.intface.EmployeeList;

public class ConsumerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 //Accept one argument and produces result
		 Consumer<String> con=(x)->System.out.println("value of x"+x);
		 con.accept("Data");
		 
		 Consumer<Integer> con1=(i)->System.out.println("Value of dta provided"+i*20);
		 con1.accept(20);
		  
	}

}
