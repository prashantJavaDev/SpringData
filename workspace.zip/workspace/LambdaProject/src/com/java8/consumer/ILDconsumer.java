package com.java8.consumer;

import java.util.function.DoubleConsumer;
import java.util.function.IntConsumer;
import java.util.function.LongConsumer;

public class ILDconsumer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		IntConsumer i = (x) -> System.out.println(x * x);
		i.accept(20);
		LongConsumer l = (y) -> System.out.println(y * y);
		l.accept(1234567);
		DoubleConsumer d = (z) -> System.out.println(z * z);
		d.accept(20.50);
	}

}
