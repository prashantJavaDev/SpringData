package com.java8.consumer;

import java.util.function.BiConsumer;

public class BiConsumerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BiConsumer<Integer,Integer> b1=(x,y)->System.out.println("Result=="+x+y);
		BiConsumer<String,Integer> b2=(x,y)->System.out.println("Result=="+x+y);
		BiConsumer<Integer,Double> b3=(x,y)->System.out.println("Result=="+x+y);
		b1.accept(20,20);
		b2.accept(" String ",20);
		b3.accept(20,20.0);
	}

}
