package com.java8.streams.filter;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class ReduseStreamExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<Integer> list=Arrays.asList(1,3,4,6,2,20);	

Optional Intlist=list.stream().reduce((a,b)->a+b);
System.out.println("data=="+Intlist.isPresent());
}

}
