package com.java8.streams.filter;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.intface.Employee;
import com.intface.EmployeeList;

public class SortedStream {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> list=EmployeeList.getEmpList();
		List<Employee>list1=list.stream()
		.sorted(Comparator.comparing(Employee::getName).reversed())
		.distinct()
		.collect(Collectors.toList());
		System.out.println(list1);
	}

}
