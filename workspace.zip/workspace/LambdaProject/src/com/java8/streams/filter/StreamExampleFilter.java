package com.java8.streams.filter;

import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.intface.Employee;
import com.intface.EmployeeList;

public class StreamExampleFilter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Predicate<Employee> p1=(emp)-> emp.getEmpID()>2;
		Predicate<Employee> p2=(emp)-> emp.getSkills().contains("Java");
		Map<String,Integer> e= EmployeeList.getEmpList().stream()
//							.filter(p1)
							.filter(p2)
							.collect(Collectors.toMap(Employee::getName, Employee::getEmpID));
		List<Employee> e2= EmployeeList.getEmpList().stream()
//				.filter(p1)
				.filter(p2)
				.collect(Collectors.toList());
		System.out.println(e);
		System.out.println(e2);
	}

}
