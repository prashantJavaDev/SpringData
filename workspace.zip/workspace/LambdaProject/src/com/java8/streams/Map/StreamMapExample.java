package com.java8.streams.Map;

import java.util.List;
import java.util.stream.Collectors;

import com.intface.Employee;
import com.intface.EmployeeList;

public class StreamMapExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> list = EmployeeList.getEmpList();
		List<String> list1 = list.stream()
				.map((emp) -> {
			return emp.getName();
		}).map((s)->s.toUpperCase())
				.collect(Collectors.toList());
		System.out.println(list1);
	}

}
