package com.java8.streams.Map;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import com.intface.Employee;
import com.intface.EmployeeList;

public class FlatMapStreamExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> list=EmployeeList.getEmpList();
		Set<String> set=list.stream()
				.map(emp->emp.getSkills())
				.flatMap(x->x.stream()).map(y->y.toUpperCase())
				.collect(Collectors.toSet());
		System.out.println(set);
	}

}
