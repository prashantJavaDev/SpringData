package com.java8.function;

import java.util.Comparator;
import java.util.function.BinaryOperator;
import java.util.function.DoubleBinaryOperator;
import java.util.function.IntBinaryOperator;
import java.util.function.LongBinaryOperator;

public class BinaryOperatorExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BinaryOperator<Integer> i=(a,b)->a*b;
		i.apply(20, 30);
		System.out.println("Data="+i.apply(20, 30));
		Comparator<Integer> c=(a,b)->a.compareTo(b);
		BinaryOperator<Integer> i2=BinaryOperator.maxBy(c);
		System.out.println("Data="+i2.apply(20, 30));
		BinaryOperator<Integer> i3=BinaryOperator.minBy(c);
		System.out.println("Data="+i3.apply(20, 30));
		IntBinaryOperator i4=(a,b)->a*b;
		System.out.println("Data="+i4.applyAsInt(20, 30));
		LongBinaryOperator i5=(a,b)->a*b;
		System.out.println("Data="+i5.applyAsLong(20, 30));
		DoubleBinaryOperator i6=(a,b)->a*b;
		System.out.println("Data="+i6.applyAsDouble(20, 30));
		
		
		
	}

}
