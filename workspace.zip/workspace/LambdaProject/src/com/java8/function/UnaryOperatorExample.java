package com.java8.function;

import java.util.function.DoubleUnaryOperator;
import java.util.function.IntUnaryOperator;
import java.util.function.LongUnaryOperator;
import java.util.function.UnaryOperator;

public class UnaryOperatorExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		UnaryOperator<Integer> u = (n) -> n * 20;
		IntUnaryOperator i = (n) -> n * 20;
		DoubleUnaryOperator d = (n) -> n * 20;
		LongUnaryOperator l = (n) -> n * 20;
		
		System.out.println(u.apply(20));
		System.out.println(i.applyAsInt(20));
		System.out.println(d.applyAsDouble(20));
		System.out.println(l.applyAsLong(20));
	}

}
