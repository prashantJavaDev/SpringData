package com.java8.function;

import java.util.function.Function;

public class FunctionExample {
public static void main(String s[]){
	Function< Integer, Double> f=(n)->Math.sqrt(n);
	System.out.println("SqrRoot"+f.apply(10));
	Function<String, String> f2=(st)->st.toLowerCase();
	System.out.println("Lower= "+f2.apply("Pk"));
	Function<String, String> f3=(st)->st.concat("Program");
	System.out.println("Lower= "+f3.andThen(f2).apply("Pk "));
	System.out.println("Lower= "+f3.compose(f2).apply("Pk "));
	
}
}
