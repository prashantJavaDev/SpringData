package com.java8.function;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;

import com.intface.Employee;
import com.intface.EmployeeList;

public class FunctionExampleObject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Function<List<Employee>, Map<String,Integer>> map=(emps)->{
			Map<String,Integer> m=new HashMap<>();
			emps.forEach((e)->{
				m.put(e.getName(), e.getEmpID());
			});
			return m;
		};
		Predicate<List<String>> p=(s)->s.contains("Java");
		Function<List<Employee>, Map<String,Integer>> map2=(emps)->{
			Map<String,Integer> m=new HashMap<>();
			emps.forEach((e)->{
				if(p.test(e.getSkills()))
				m.put(e.getName(), e.getEmpID());
			});
			return m;
		};
		System.out.println("data=="+map2.apply(EmployeeList.getEmpList()));
	}

}
