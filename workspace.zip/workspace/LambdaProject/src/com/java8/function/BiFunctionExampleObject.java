package com.java8.function;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Predicate;

import com.intface.Employee;
import com.intface.EmployeeList;

public class BiFunctionExampleObject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Predicate<Employee> p2=(e2)->e2.getEmpID()>2;
		BiFunction<List<Employee>, Predicate<Employee> ,Map<Integer,Employee>> b=(emps,p)->{
			Map<Integer,Employee> map=new HashMap<Integer, Employee>();
			emps.forEach((e)->{
				if(p.test(e)){
					map.put(e.getEmpID(), e);
				}
			});
			return map;
		};
	System.out.println("data==="+b.apply(EmployeeList.getEmpList(), p2));	
	}

}
