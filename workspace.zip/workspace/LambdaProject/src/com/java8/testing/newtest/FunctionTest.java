package com.java8.testing.newtest;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;

import com.intface.Employee;
import com.intface.EmployeeList;

public class FunctionTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Employee> list1=EmployeeList.getEmpList();
		Function<Employee, String> f1=(x)->x.getName();
		Function<List<Employee>, Map<String,Float>> f2=(emps)->{
			Map<String,Float> map=new HashMap<String, Float>();
			for(Employee e:emps){
				map.put(e.getName(),e.getSalary());
				}
			return map;
		};
	
		Predicate<Employee> p=e->e.getEmpID()>2;
		Function<List<Employee>, List<String>> f3=(emps)->{
			List<String> list=new ArrayList<>();
			for(Employee e:emps){
				if(p.test(e)){
					list.add(e.getName());
				}
			}
			return list;
		};
		
		
		
		
		list1.forEach(emp->{
			System.out.println(f1.apply(emp));
		});
		System.out.println(f2.apply(list1));
		System.out.println(f3.apply(list1));
	}
	

}
