package com.java8.testing.newtest;


import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Consumer;

import javax.swing.plaf.synth.SynthScrollBarUI;

import com.intface.Employee;
import com.intface.EmployeeList;

public class BiConsumerTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> list=EmployeeList.getEmpList();
		Consumer<Employee> c1=(em)->System.out.println("Employee="+em);
		Consumer<Employee> c2=(em)->System.out.println("name="+em.getName());
		Consumer<Employee> c3=(em)->System.out.println("salary="+em.getSalary());
		Consumer<Employee> c4=(em)->System.out.println("skills="+em.getSkills());
		list.forEach(c1);
		list.forEach(c2);
		list.forEach(c3);
		list.forEach(c4);
		list.forEach(c1.andThen(c3).andThen(c3).andThen(c4));
		list.forEach((e)->{
			if(e.getEmpID()>2)
				System.out.println("emploee name"+e.getName());
		});
		
		System.out.println("----------------BiConsumer----------------");
		BiConsumer<String ,String> b1=(x,y)->System.out.println("firstname"+x+" lastname="+y);
		BiConsumer<String ,List<String>> b2=(x,y)->System.out.println("firstname"+x+" lastname="+y);
		BiConsumer<String ,Float> b3=(x,y)->System.out.println("firstname"+x+" lastname="+y);
		list.forEach((emp)->b1.accept(emp.getName(), emp.getLastName()));
		list.forEach((emp)->b2.accept(emp.getName(), emp.getSkills()));
		list.forEach((emp)->b3.accept(emp.getName(), emp.getSalary()));
	}

}
