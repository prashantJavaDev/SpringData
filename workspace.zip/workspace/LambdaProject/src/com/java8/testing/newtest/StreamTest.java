package com.java8.testing.newtest;

import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.intface.Employee;
import com.intface.EmployeeList;

public class StreamTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> list=EmployeeList.getEmpList();
		List<List<String>> l1=list.stream()
		.filter(e->e.getSalary()>5000)
		.map(Employee::getSkills)
		.collect(Collectors.toList());
		System.out.println(l1);
		List<String> l2=list.stream()
		.filter(e->e.getSalary()>5000)
		.map(Employee::getSkills)
		.flatMap(List::stream)
		.map(String::toLowerCase)
		.sorted()
		.distinct()
		.collect(Collectors.toList());
		System.out.println(l2);
		
		Optional<Employee> p=list.stream()
		.sorted(Comparator.comparing(Employee::getSalary))
		.skip(1)
		.findFirst();
		System.out.println(p.get());
	}
	

}
