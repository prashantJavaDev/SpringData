package com.java8.testing.newtest;

import java.util.List;
import java.util.function.BiPredicate;
import java.util.function.DoublePredicate;
import java.util.function.IntPredicate;
import java.util.function.LongPredicate;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import com.intface.Employee;
import com.intface.EmployeeList;

public class PredicateTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		List<Employee> list=EmployeeList.getEmpList();
		Predicate<Employee> p1=(emp)->emp.getEmpID()>2;
		Predicate<Employee> p2=(emp)->emp.getSalary()>50000;
		Predicate<Employee> p3=(emp)->emp.getSkills()
				.stream()
				.map(String::toLowerCase)
				.collect(Collectors.toList())
				.contains("java");
		
		list.forEach(emp->{
		if(p1.test(emp))
			System.out.println("p1"+emp);});
		list.forEach(emp->{
			if(p2.test(emp))
				System.out.println("p2"+emp);});
		list.forEach(emp->{
			if(p3.test(emp))
				System.out.println("p3"+emp);});
		
		System.out.println("--------------Bipredicate--------------");
		
		BiPredicate<Integer, Integer> b1=(x,y)->x>2 && y<5;
		BiPredicate<Float, Float> b2=(x,y)->x>5000 && y<75000 ;
		BiPredicate<Integer, List<String>> b3=(x,y)->x>2 && y.contains("Java");
		
		list.forEach(emp->{
			if(b1.test(emp.getEmpID(), emp.getEmpID())){
				System.out.println("b1"+emp);
			}
		});
		list.forEach(emp->{
			if(b2.test(emp.getSalary(), emp.getSalary())){
				System.out.println("b2"+emp);
			}
		});
		list.forEach(emp->{
			if(b3.test(emp.getEmpID(), emp.getSkills())){
				System.out.println("b3"+emp);
			}
		});
		
		IntPredicate i=x->x>2; 
		DoublePredicate d=x->x>2;
		LongPredicate l=x->x>2;
		System.out.println(i.test(0));
		System.out.println(d.test(19));
		System.out.println(l.test(21));
		
	}
}
