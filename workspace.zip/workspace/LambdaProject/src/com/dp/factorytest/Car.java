package com.dp.factorytest;

public interface Car {
	public String engine();
}
