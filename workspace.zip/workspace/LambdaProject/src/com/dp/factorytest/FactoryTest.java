package com.dp.factorytest;

public class FactoryTest {
	public static void main(String a[]) {
		Car c=CarFactory.getCar(1);
		System.out.println(c.engine());
	}
}
