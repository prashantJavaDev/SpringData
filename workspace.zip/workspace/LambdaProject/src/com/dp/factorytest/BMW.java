package com.dp.factorytest;

public class BMW implements Car{
	@Override
	public String engine(){
		return "BMW Engine";
	}

}
