package com.dp.factorytest;

public class CarFactory {
	public static Car getCar(int i){
			if(i==0){
				return new Tata();
			}else{
				return new BMW();
			}
	}
}
