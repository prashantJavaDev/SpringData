package com.dp.singletonTest;

public class SingletonDemo implements Cloneable {
	private static SingletonDemo instance;

	private SingletonDemo() {
	}

	public static SingletonDemo getInstance() {
		synchronized (SingletonDemo.class) {
			if (instance != null) {
				return instance;
			} else {
				return instance = new SingletonDemo();
			}
		}
	}

	public Object readResolve() {
		return getInstance();
	}

	public Object clone() throws CloneNotSupportedException {
		return getInstance();
	}
}
