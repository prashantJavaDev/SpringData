package com.intface;

import java.util.List;

public class Employee {
	private String name;
	private String lastName;
	private int empID;
	private float salary;
	private String gender;
	private List<String> skills;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getEmpID() {
		return empID;
	}
	public void setEmpID(int empID) {
		this.empID = empID;
	}
	public float getSalary() {
		return salary;
	}
	public void setSalary(float salary) {
		this.salary = salary;
	}
	public List<String> getSkills() {
		return skills;
	}
	public void setSkills(List<String> skills) {
		this.skills = skills;
	}
	
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	
	@Override
	public String toString() {
		return "Employee [name=" + name + ", lastName=" + lastName + ", empID=" + empID + ", salary=" + salary
				+ ", gender=" + gender + ", skills=" + skills + "]";
	}
	public Employee(String name, String lastName, int empID, float salary, List<String> skills,String gender) {
		super();
		this.name = name;
		this.lastName = lastName;
		this.empID = empID;
		this.salary = salary;
		this.skills = skills;
		this.gender = gender;
	}
	
	
	

}
