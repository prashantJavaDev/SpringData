package com.intface;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EmployeeList {
	public static List<Employee> getEmpList() {
		List<Employee> list = new ArrayList<>();
		list.add(new Employee("Pk", "Ka", 1, 30000, Arrays.asList("Java", "DB"),"M"));
		list.add(new Employee("KP", "Kap", 2, 40000, Arrays.asList(".net", "Ab"),"M"));
		list.add(new Employee("Art", "Ka", 3, 50000, Arrays.asList("JAVA", "XX"),"F"));
		list.add(new Employee("GAi", "Ka", 4, 60000, Arrays.asList("SQl", "TEst"),"F"));
		list.add(new Employee("RAh", "Ka", 5, 70000, Arrays.asList("Java", "angular"),"M"));
		return list;
	}
}
