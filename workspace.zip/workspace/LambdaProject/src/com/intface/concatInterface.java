package com.intface;
@FunctionalInterface
public interface concatInterface {
	String concat(String a,String B); 

}
