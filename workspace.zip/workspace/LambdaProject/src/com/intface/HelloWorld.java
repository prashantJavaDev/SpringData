package com.intface;

import java.util.Collections;

public interface HelloWorld {
public String sayHello();

}
