package com.intface;

public interface IncByFive {
public int incByFive(int i);
}
