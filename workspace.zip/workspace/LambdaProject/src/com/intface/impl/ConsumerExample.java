package com.intface.impl;

import java.util.List;
import java.util.function.Consumer;

import com.intface.Employee;
import com.intface.EmployeeList;

public class ConsumerExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Employee> empList=EmployeeList.getEmpList();
		Consumer<Employee> c1=(emp)->{
			System.out.println("Data="+emp.toString());
			};
			Consumer<Employee> c2=(emp)->{
				System.out.println("Data="+emp.getName());
			};
			Consumer<Employee> c3=(emp)->{
				System.out.println("Data="+emp.getSkills());
			};
			Consumer<Employee> c4=(emp)->{
				System.out.println("Data="+emp.getSalary());
			};
			Consumer<Employee> c5=(emp)->{
				System.out.println("Data="+emp.getEmpID());
			};
		empList.forEach(c1);
		empList.forEach(c2);
		empList.forEach(c2.andThen(c3));
		empList.forEach(emp->{
			if(emp.getEmpID()>=3){
				System.out.println(emp.getName()+" "+emp.getSalary());
				c2.andThen(c1).andThen(c3).andThen(c4).accept(emp);
			}
		});
		

	}

}
