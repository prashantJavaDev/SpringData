package com.intface.impl;

public class ThreadByLamda {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Runnable r=()->{
			int i=5;
			for(int x=1;x<=10;x++){
				i=i+5;
			}
			System.out.println(i);
		};
		
		new Thread(()->{
			int i=5;
			for(int x=1;x<=10;x++){
				i=i+5;
			}
			System.out.println(i);
		}).start();
	}
}
