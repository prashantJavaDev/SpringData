package com.intface.impl;

import com.intface.HelloWorld;
import com.intface.IncByFive;
import com.intface.concatInterface;

public class HelloImpl {
	public static void main(String[] s) {
		HelloWorld h = () ->  "Helloworld";
		
		System.out.println("data="+h.sayHello());
		
	concatInterface c=(a,b)->a+" "+b;
	
	System.out.println(c.concat("data", "FAF"));
	IncByFive inc=(i)->i+5;
	System.out.println(inc.incByFive(100));
	}
}
