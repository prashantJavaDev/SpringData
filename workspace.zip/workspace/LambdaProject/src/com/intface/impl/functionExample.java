package com.intface.impl;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class functionExample {
	public static void main(String a[]){
	List<Integer> list=Arrays.asList(1,2,3,4,5,3,2);
	List<Integer> list1=list.stream().sorted().distinct().collect(Collectors.toList());
	System.out.println("data"+list1);
	System.out.println(list.stream().sorted().distinct().mapToInt(v->v).min().orElse(0));
	System.out.println(list.stream().sorted().distinct().mapToInt(v->v).reduce(0,(ac,b)->ac+b));
	System.out.println(list.stream().sorted().distinct().mapToInt(v->v+2).reduce(0,(ac,b)->ac+b));
	System.out.println(list.stream().sorted().distinct().mapToInt(v->v).anyMatch((x)-> x>2));
	System.out.println(list.stream().sorted().distinct().mapToInt(v->v).allMatch((x)-> x>2));
	System.out.println(list.stream().sorted().distinct().mapToInt(v->v).noneMatch((x)-> x>6));
	System.out.println(list.stream().sorted().distinct().limit(2).collect(Collectors.toSet()));
	System.out.println(list.stream().sorted().distinct().limit(2).collect(Collectors.toSet()));
	System.out.println(list.stream().sorted().distinct().skip(2).collect(Collectors.toSet()));
	}

}
