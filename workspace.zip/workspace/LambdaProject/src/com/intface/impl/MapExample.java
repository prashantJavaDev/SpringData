package com.intface.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import com.intface.Employee;
import com.intface.EmployeeList;

public class MapExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Predicate<Employee> p1=(e)->e.getEmpID()>2;
	List<String> list=EmployeeList.getEmpList().stream()
			.filter(p1)
			.filter((emp)->emp.getName().startsWith("A"))
			.map(Employee::getName).collect(Collectors.toList());
	System.out.println(list);
	
	
	List<String> aList = new ArrayList<String>();
	aList.add("a");
	aList.add("b");
	aList.add("c");
	aList.add("d");
	aList.add("e");

	List<String> bList = new ArrayList<String>();
	bList.add("b");
	bList.add("e");
	bList.add("d");

	aList.removeAll(bList);
	System.out.println(aList);
	}

}
