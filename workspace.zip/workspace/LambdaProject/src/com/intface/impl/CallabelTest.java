package com.intface.impl;

import java.util.concurrent.Callable;

public class CallabelTest {
	public static void main(String[] s) throws Exception{
		Callable<Integer> c=()->{
			int i=50;
			int sum=0;
			for(int x=0;x<=i;x++){
			sum=sum+x;
			}
			return sum;
		};
		Integer f=c.call();
		System.out.println("Data==="+f);
	}

}
