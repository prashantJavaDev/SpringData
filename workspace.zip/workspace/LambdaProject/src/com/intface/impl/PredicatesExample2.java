package com.intface.impl;

import java.util.List;
import java.util.function.BiConsumer;
import java.util.function.Predicate;

import com.intface.Employee;
import com.intface.EmployeeList;

public class PredicatesExample2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Predicate<Employee> p1=(emp)->emp.getEmpID()==2;
		Predicate<Employee> p2=(emp)->emp.getName().equals("Pk");
		Predicate<Employee> p3=(emp)->emp.getSalary()>30000;
		Predicate<Employee> p4=(emp)->emp.getSkills().contains("Java");
		BiConsumer<String, Integer> b1=(name,id)->{
			System.out.println("Name=="+name+" Id="+id);
		};
	List<Employee>list=EmployeeList.getEmpList();
	list.forEach(em->{
		if(p4.test(em))
		{
			b1.accept(em.getLastName(), em.getEmpID());
		}
	});
	list.forEach(em->{
		if(p4.test(em))
		{
			System.out.println(em);
		}
	});
	}

}
