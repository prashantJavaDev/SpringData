package com.intface.impl;

import java.util.function.Predicate;

public class PredicateExample {
	public static void main(String[] args) {
		Predicate<Integer> p1=(a)->a>10;
		System.out.println(p1.test(15));
		Predicate<Integer> p2=(a)->a%2==0;
		System.out.println(p1.and(p2).negate().test(15));
		System.out.println(p1.and(p2).test(15));
	}

}
