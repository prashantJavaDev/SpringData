package com.intface.impl;

import java.util.List;
import java.util.function.BiConsumer;

import com.intface.Employee;
import com.intface.EmployeeList;

public class BiConsumerExample {
	public static void main(String[] args) {
		List<Employee> empList=EmployeeList.getEmpList();
		BiConsumer<String,String> b1=(name,lastname)->System.out.println("Data="+name+lastname); 
		empList.forEach(emp->{
			b1.accept(emp.getName(),emp.getLastName());
		});
		BiConsumer<String,List<String>> b2=(name,skill)->System.out.println("Data="+name+skill); 
		empList.forEach(emp->{
			b2.accept(emp.getName(),emp.getSkills());
		});
		
		empList.forEach(emp->{
			if(emp.getEmpID()>4)
			b2.accept(emp.getName(),emp.getSkills());
		});
	}
	
	
}
