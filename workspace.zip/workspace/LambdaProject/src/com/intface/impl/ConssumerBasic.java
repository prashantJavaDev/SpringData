package com.intface.impl;

import java.util.function.Consumer;

public class ConssumerBasic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Consumer<Integer> i=(id)->{
			System.out.println("id=="+id);		
		};
		i.accept(60);
		Consumer<String> s=(Str)->{
			System.out.println("lenght=="+Str.length());		
		};
		s.accept("Jam arha ahai");
	}

}
