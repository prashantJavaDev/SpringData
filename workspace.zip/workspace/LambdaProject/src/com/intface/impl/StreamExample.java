package com.intface.impl;

import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import com.intface.Employee;
import com.intface.EmployeeList;

public class StreamExample {
public static void main(String[] a){

	Predicate<Employee> p1=(emp)-> emp.getEmpID()>3;


List<Employee>list =EmployeeList.getEmpList();
//Map<String,List<String>> li=list.stream().
//							filter(p1).
//							collect(Collectors.toMap(Employee::getName, Employee::getSkills));


List<String> list1=list.stream().
map(Employee::getSkills)
.flatMap(list2->list2.stream()).map(String::toLowerCase).distinct()
.collect(Collectors.toList());
System.out.println(list1);

}


}
