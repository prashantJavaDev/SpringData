package com.designpattern.flyweight;

import java.util.HashMap;
import java.util.Map;

public class PenFactory {
	private static final Map<String, Pen> map = new HashMap<String, Pen>();

	public static Pen getThickPen(String color) {
		String key = color + "THIK";
		Pen obj = map.get(key);
		if (obj != null) {
			return obj;
		} else {
			obj = new ThickPen();
			obj.setcolor(color);
			map.put(key, obj);
			return obj;
		}
	}

	public static Pen getThinPen(String color) {
		String key = color + "THIN";
		Pen obj = map.get(key);
		if (obj != null) {
			return obj;
		} else {
			obj = new ThinPen();
			obj.setcolor(color);
			map.put(key, obj);
			return obj;
		}

	}
}
