package com.designpattern.flyweight;

public class ThinPen implements Pen{
	private final BrusSizz bz=BrusSizz.THIK;
	private String color=null;
	@Override
	public void setcolor(String color) {
		this.color=color;
	}
	@Override
	public void draw(String content) {
		System.out.println("inside Draw of THisk"+content+" color"+color);
	}
	
	

}
