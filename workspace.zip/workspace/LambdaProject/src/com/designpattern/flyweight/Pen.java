package com.designpattern.flyweight;

public interface Pen {
public void setcolor(String color);
public void draw(String content);
}
