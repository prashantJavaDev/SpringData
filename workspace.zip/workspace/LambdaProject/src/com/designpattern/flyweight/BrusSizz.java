package com.designpattern.flyweight;

public enum BrusSizz {
THIK,THIN;
}
