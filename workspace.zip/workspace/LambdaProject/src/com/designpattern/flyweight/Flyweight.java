package com.designpattern.flyweight;

public class Flyweight {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Pen p=PenFactory.getThickPen("RED");
		Pen p2=PenFactory.getThickPen("RED");
		Pen p3=PenFactory.getThinPen("RED");
		Pen p4=PenFactory.getThinPen("RED");
		p.draw("THick");
		p2.draw("THick");
		p3.draw("Thin");
		p4.draw("Thin");
		System.out.println("hashcode=="+p);
		System.out.println("hashcode=="+p2);
		System.out.println("hashcode=="+p3);
		System.out.println("hashcode=="+p4);

	}

}
