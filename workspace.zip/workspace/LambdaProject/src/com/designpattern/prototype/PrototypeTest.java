package com.designpattern.prototype;

public class PrototypeTest {

	public static void main(String[] args) throws CloneNotSupportedException{
		// TODO Auto-generated method stub
		Employee ex=new Employee();
		ex.setId(1);
		ex.setName("Pk");
		System.out.println("Employuee="+ex+" Hashcode"+ex.hashCode());
		Employee e=(Employee)ex.clone();
		System.out.println("Employuee="+e+" Hashcode"+e.hashCode());
	}

}
