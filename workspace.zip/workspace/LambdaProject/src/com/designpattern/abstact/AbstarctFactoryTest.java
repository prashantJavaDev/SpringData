package com.designpattern.abstact;

public class AbstarctFactoryTest {
	public static void main(String a[]){
		CarAbstactFactory s=CarFactoryProvider.getCarFactory("super");
		Car c=s.getCar(0);
		c.engineSound();
		CarAbstactFactory s1=CarFactoryProvider.getCarFactory("professional");
		Car c1=s1.getCar(1);
		c1.engineSound();
	}

}
