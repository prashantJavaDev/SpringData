package com.designpattern.abstact;

public interface Car {
	public void engineSound();
}
