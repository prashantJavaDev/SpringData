package com.designpattern.abstact;

public class ProfessionalCarFactory extends CarAbstactFactory{
	@Override
	public Car getCar(int i){
		if(i==0)
		return new Tata();
		else
			return new Maruti();
	}
}
