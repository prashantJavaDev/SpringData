package com.designpattern.abstact;

public class SuperCarFactory extends CarAbstactFactory {

	@Override
	public Car getCar(int i) {
		// TODO Auto-generated method stub
		return new BMW();
	}

}
