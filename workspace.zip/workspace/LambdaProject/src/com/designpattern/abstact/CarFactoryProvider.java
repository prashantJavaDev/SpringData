package com.designpattern.abstact;

public class CarFactoryProvider {
	public static CarAbstactFactory getCarFactory(String s){
		if(s==null)
			return null;
		if(s.equalsIgnoreCase("super")){
			return new SuperCarFactory();
		}else if(s.equalsIgnoreCase("professional")){
				return new ProfessionalCarFactory();
		}
			return null;
	
}
}
