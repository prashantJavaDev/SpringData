package com.designpattern.abstact;

public class BMW implements Car {

	@Override
	public void engineSound() {
		// TODO Auto-generated method stub
		System.out.println("BMW Engine sound");
	}

}
