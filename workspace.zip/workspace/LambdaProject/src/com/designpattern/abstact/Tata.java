package com.designpattern.abstact;

public class Tata implements Car {

	@Override
	public void engineSound() {
		// TODO Auto-generated method stub
		System.out.println("Tata Engine sound");
	}

}
