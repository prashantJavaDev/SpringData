package com.designpattern.abstact;

public abstract class CarAbstactFactory {
	public abstract Car getCar(int i);
}
