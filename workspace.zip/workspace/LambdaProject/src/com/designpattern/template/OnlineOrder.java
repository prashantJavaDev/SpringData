package com.designpattern.template;

public class OnlineOrder extends Order {

	@Override
	public void doSelect() {
		// TODO Auto-generated method stub
		System.out.println("seleyted product");
		
	}

	@Override
	public void docheckout() {
		// TODO Auto-generated method stub
		System.out.println("checkout product");
		
	}

	@Override
	public boolean doPayment() {
		// TODO Auto-generated method stub
		System.out.println("payment DOen product");
		return true;
	}

	@Override
	public boolean doDelivery() {
		// TODO Auto-generated method stub
		System.out.println("Deliver product");
		return true;
	}
	
	public void test(){
		
	}

}
