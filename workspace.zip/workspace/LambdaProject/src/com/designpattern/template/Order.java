package com.designpattern.template;

public abstract class Order {
	
	public abstract void doSelect(); 
	public abstract void docheckout(); 
	public abstract boolean doPayment(); 
	public abstract boolean doDelivery(); 
	
	public void processOrder(){
		doSelect();
		docheckout();
		if(doPayment())
		doDelivery();
	}

	
}
