package com.designpattern.template;

public class ORderTemplateTest {
	public static void main(String a[]){
		Order o= new OnlineOrder();
		
		o.processOrder();
	}
}
