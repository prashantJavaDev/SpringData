package com.designpattern.builder;

public class BuilderTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Computer c=new Computer.ComputerBiulder(8,250,"PErsonal")
		.isBluetoothEnable(true)
		.isGraphicsEnable(true)
		.build();
		System.out.println("Compurt=="+c);

	}

}
