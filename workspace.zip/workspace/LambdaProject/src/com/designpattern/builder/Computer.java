package com.designpattern.builder;

public class Computer {
private int ram;
private int hdd;
private String name;
private boolean isBluetoothEnable;
private boolean isGraphicsEnable;
public Computer(int ram, int hdd, String name) {
	super();
	this.ram = ram;
	this.hdd = hdd;
	this.name = name;
}
public int getRam() {
	return ram;
}
public void setRam(int ram) {
	this.ram = ram;
}
public int getHdd() {
	return hdd;
}
public void setHdd(int hdd) {
	this.hdd = hdd;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public boolean isBluetoothEnable() {
	return isBluetoothEnable;
}
public void setBluetoothEnable(boolean isBluetoothEnable) {
	this.isBluetoothEnable = isBluetoothEnable;
}
public boolean isGraphicsEnable() {
	return isGraphicsEnable;
}
public void setGraphicsEnable(boolean isGraphicsEnable) {
	this.isGraphicsEnable = isGraphicsEnable;
}
private Computer(ComputerBiulder c){
	this.ram=c.ram;
	this.hdd=c.hdd;
	this.name=c.name;
	this.isBluetoothEnable=c.isBluetoothEnable;
	this.isGraphicsEnable=c.isGraphicsEnable;
}
public static class ComputerBiulder{
	private int ram;
	private int hdd;
	private String name;
	private boolean isBluetoothEnable;
	private boolean isGraphicsEnable;
	
	public ComputerBiulder(int ram, int hdd, String name) {
		super();
		this.ram = ram;
		this.hdd = hdd;
		this.name = name;
	}
	public ComputerBiulder isBluetoothEnable(boolean isBluetoothEnable){
		this.isBluetoothEnable=isBluetoothEnable;
		return this;
	}
	public ComputerBiulder isGraphicsEnable(boolean isGraphicsEnable){
		this.isGraphicsEnable=isGraphicsEnable;
		return this;
	}
	public Computer build (){
		return new Computer(this);
	}
}
@Override
public String toString() {
	return "Computer [ram=" + ram + ", hdd=" + hdd + ", name=" + name + ", isBluetoothEnable=" + isBluetoothEnable
			+ ", isGraphicsEnable=" + isGraphicsEnable + "]";
}

}
