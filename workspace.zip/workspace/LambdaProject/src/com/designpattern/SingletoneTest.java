package com.designpattern;

import java.lang.reflect.Constructor;

public class SingletoneTest {

	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		SingletoneDesignPattern singletoneDesignPattern=SingletoneDesignPattern.getInstance();
		SingletoneDesignPattern singletoneDesignPattern2=SingletoneDesignPattern.getInstance();
		SingletoneDesignPattern singletoneDesignPattern3=SingletoneDesignPattern.getInstance();
		SingletoneDesignPattern singletoneDesignPattern4=SingletoneDesignPattern.getInstance();
		System.out.println(singletoneDesignPattern.toString());
		System.out.println(singletoneDesignPattern2.toString());
		System.out.println(singletoneDesignPattern3.toString());
		System.out.println(singletoneDesignPattern4.toString());
		SingletoneDesignPattern singletoneDesignPattern5=null;
		Constructor[] s=SingletoneDesignPattern.class.getDeclaredConstructors();
		for (Constructor constructor : s) {
			constructor.setAccessible(true);
			singletoneDesignPattern5=(SingletoneDesignPattern)constructor.newInstance();
			break;
		}
		System.out.println(singletoneDesignPattern5.toString());
	}

}
