package com.designpattern.factory;

import java.util.HashMap;
import java.util.Map;

public class CarFactoy {
	public static Map<String,Car> map=new HashMap<>();
	public static Car getInstance(int choice){
		String key=choice+"Car";//0Car
		Car car=map.get(key);
			if(choice==0){
				if(car==null){
					Car mcar=new Maruti();
					map.put(key, mcar);
					return mcar;
				}else{
					return car;
				}
		}else if(choice==1){
			if(car==null){
				Car bcar=new BMW();
				map.put(key, bcar);
				return bcar;
			}else{
				return car;
			}
		}else{
			return null;
		}
	}

}
