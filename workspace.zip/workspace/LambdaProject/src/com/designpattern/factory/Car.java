package com.designpattern.factory;

public interface Car {
public abstract String sound();
}
