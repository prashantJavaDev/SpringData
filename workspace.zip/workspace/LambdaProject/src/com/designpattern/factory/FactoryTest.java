package com.designpattern.factory;

public class FactoryTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Car c1=CarFactoy.getInstance(0);
		Car c2=CarFactoy.getInstance(1);
		c1.sound();
		c2.sound();
	}

}
