package com.designpattern.factory;

public class Maruti implements Car{

	@Override
	public String sound() {
		// TODO Auto-generated method stub
		System.out.println("maruti car sound");
		return "maruti car sound";
	}

}
