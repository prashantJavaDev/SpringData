package com.designpattern.factory;

public class BMW implements Car {
	@Override
	public String sound() {
		// TODO Auto-generated method stub
		System.out.println("BMW car sound");
		return "BMW car sound";
	}


}
