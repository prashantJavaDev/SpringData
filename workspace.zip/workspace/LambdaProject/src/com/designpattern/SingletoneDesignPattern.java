package com.designpattern;

import java.util.concurrent.SynchronousQueue;
//to avoid Reflection problem use Enum
//   enum SingletoneDesignPatternEnum {
//
//    INSTANCE;
    
//    public static void doSomething(){
//        //do something
//    }
//}
 
public class SingletoneDesignPattern implements Cloneable{
	public static SingletoneDesignPattern instance=new SingletoneDesignPattern();
	private SingletoneDesignPattern(){
		
	}
	public static SingletoneDesignPattern getInstance(){
		synchronized(SingletoneDesignPattern.class){
			return instance;
		}
	}
	
	protected Object clone() throws CloneNotSupportedException{
		throw new CloneNotSupportedException();
		
	}
	@Override
	public String toString() {
		return "SingletoneDesignPattern [hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	
	protected Object readResolve() {
	    return getInstance();
	}
	

}
