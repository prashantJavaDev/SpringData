package com.designpattern.abstracttest;

public interface CarFactory {
public Car getCar(int i);
}
