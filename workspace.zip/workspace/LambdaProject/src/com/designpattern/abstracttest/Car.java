package com.designpattern.abstracttest;

public interface Car {
	public String engine();
}
