package com.designpattern.abstracttest;

public  class ProfessionalCarFactory implements CarFactory {
	@Override
public Car getCar(int i){
	if(i==0){
		return new Tata();
	}else{
		return null;
	}
}
}
