package com.designpattern.abstracttest;

public  class SportCarFactory implements CarFactory {
	@Override
	public Car getCar(int i){
		if(i==2){
			return new BMW();
		}else{
			return null;
		}
	}

}
