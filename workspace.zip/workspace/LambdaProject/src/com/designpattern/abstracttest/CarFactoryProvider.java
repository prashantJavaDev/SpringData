package com.designpattern.abstracttest;

public class CarFactoryProvider {
public static CarFactory getFactory(String s){
	if(s.equals("P")){
		return new ProfessionalCarFactory(); 
	}else if(s.equals("S")){
		return new SportCarFactory() ;
	}else{
		return null;
	}
}
}
