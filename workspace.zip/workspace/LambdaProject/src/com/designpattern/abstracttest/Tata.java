package com.designpattern.abstracttest;

public class Tata implements Car{

	@Override
	public String engine() {
		// TODO Auto-generated method stub
		return "Tata Engine";
	}
	

}
