package com.designpattern.abstracttest;

public class BMW implements Car{
	@Override
	public String engine(){
		return "BMW Engine";
	}

}
