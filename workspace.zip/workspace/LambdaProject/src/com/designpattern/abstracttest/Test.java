package com.designpattern.abstracttest;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(CarFactoryProvider.getFactory("P").getCar(0).engine());
		System.out.println(CarFactoryProvider.getFactory("S").getCar(2).engine());
	}

}
