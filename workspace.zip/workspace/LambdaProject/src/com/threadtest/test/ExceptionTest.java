package com.threadtest.test;

import java.text.DecimalFormat;

public class ExceptionTest {
public int getAnswer(){
	try{
		try{
			return 5;
		}catch(ArrayIndexOutOfBoundsException a){
			
			System.out.println("inner catch");
			return 4;
		}
		finally{
			
			System.out.println("inner FInaaly");
			return 3;
			
		}
	}catch(NullPointerException e){
		
		System.out.println("outer catch");
		return 2;
	}
	finally{
		System.out.println("outer FInaaly");
		return 1;
	}
}




public static void main(String a[]){

	DecimalFormat d=new DecimalFormat();
	d.applyPattern("#0.00");
	
	System.out.println("main "+d.format(123455));
	System.out.println("main "+d.format(1234.55));
	System.out.println("main "+d.format(12345.5));
	
}
}
