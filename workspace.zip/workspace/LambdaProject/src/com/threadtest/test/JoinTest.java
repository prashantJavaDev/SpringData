package com.threadtest.test;

public class JoinTest  {
	private  void getValue(int s){
		System.out.println("in String");
		
	}
private  void getValue(short s){
	System.out.println("in Objedt");
		
	}
	public static int count=0;
	public static void main(String a[])throws Exception{
		JoinTest j=new JoinTest();
		j.getValue(5);
		
		Thread t=new Thread(()->{
		for(int k=0;k<10;k++){
			try {
				Thread.sleep(10L);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println("COunter thread1  "+count);
			count++;
		}
		});
		Thread t2=new Thread(()->{
			for(int k=0;k<10;k++){
				try {
					Thread.sleep(10L);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("COunter thread2  "+count);
				count++;
			}
			});
		t.start();
		t2.start();
		t.join();
		t2.join();
//		for(int k=0;k<100;k++){
//			System.out.println("COunter MAin"+count);
//			count++;
//		}
	}

}
