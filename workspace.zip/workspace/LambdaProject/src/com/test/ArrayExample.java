package com.test;

public class ArrayExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[] = new int[] { 3, 5, 2, 4,  9,  3,
                1, 7, 3, 11, 12, 3 };
int x = 3, k = 3;
int n = arr.length;
//System.out.println(findNUmber(n, arr, x, k));
System.out.println(getMin(arr));
System.out.println(getMax(arr));
System.out.println(factorial(4));

	}
	public static boolean findNUmber(int l,int[] a,int x,int k){
		boolean ret=false;
		for(int i=0;i<l;i=i+k){
			for(int j=0;j<k;j++){
				if(a[i+j]==k && i+j<l){
					ret=true;
					break;
					}
				if(i+j>=l || j+1==k)
				return false;
				
			}
		}
		
		return ret;
	}
	static int getMin(int a[]){
		int l=a.length;
		int res=a[0];
		for(int i=1;i<l;i++){
			if(res>a[i])
				res=a[i];
		}
		return res;
	}
	
	static int getMax(int a[]){
		int l=a.length;
		int res=a[0];
		for(int i=1;i<l;i++){
			if(res<a[i])
				res=a[i];
		}
		return res;
	}
	
	   static int factorial(int n){      
	          if (n == 1)      
	            return 1;      
	          else      
	            return(n * factorial(n-1));      
	    }      
	  
	
}
