package streamtest.latest;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import com.intface.Employee;
import com.intface.EmployeeList;

public class MapTest {
	public static void main(String a[]){
		List<Employee> list=EmployeeList.getEmpList();
		List<List<String>> list1= list.stream()
		.filter((e)->e.getSalary()>40000)
		.map((emp)->emp.getSkills())
		.collect(Collectors.toList());
		System.out.println("normal Map="+list1);
		List<String> list2= list.stream()
				.filter((e)->e.getSalary()>40000)
				.map((emp)->emp.getSkills()).flatMap(List::stream)
				.map((s)->s.toUpperCase())
				.collect(Collectors.toList());
		System.out.println("Flat Map="+list2);
		List<String> list3= list.stream()
				.filter((e)->e.getSalary()>40000)
				.map((emp)->emp.getSkills()).flatMap(List::stream)
				.map((s)->s.toUpperCase())
				.distinct()
				.collect(Collectors.toList());
		System.out.println("flat Map with distinct="+list3);
		List<String> list4= list.stream()
				.filter((e)->e.getSalary()>40000)
				.map((emp)->emp.getSkills()).flatMap(List::stream)
				.map((s)->s.toUpperCase())
				.distinct()
				.sorted()
				.collect(Collectors.toList());
		System.out.println("flat Map with distinct sorted="+list4);
		List<String> list5= list.stream()
				.filter((e)->e.getSalary()>40000)
				.map((emp)->emp.getSkills()).flatMap(List::stream)
				.map((s)->s.toUpperCase())
				.distinct()
				.sorted(Comparator.reverseOrder())
				.collect(Collectors.toList());
		System.out.println("flat Map with distinct reverse sorted="+list5);
		
		List<Employee> list6= list.stream()
				.sorted(Comparator.comparing(Employee::getName))
				.collect(Collectors.toList());
		System.out.println("sorted by empli name="+list6);
		
		List<String> list7= list.stream()
		.sorted(Comparator.comparing(Employee::getName))
		.map((emp)-> emp.getName())
		.collect(Collectors.toList());
		System.out.println("sorted by empli name ony name ="+list7);
	}

}
