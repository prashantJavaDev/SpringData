package consumer.latest;

import java.util.List;
import java.util.function.Consumer;

import com.intface.Employee;
import com.intface.EmployeeList;

public class ConsumerTest {
public static void main(String a[]){
	List<Employee> list=EmployeeList.getEmpList();
	Consumer<String> c1=(s)->System.out.println("Start form consumer "+s);
	Consumer<Employee> c2=(s)->System.out.println("Start form consumer ID "+s.getEmpID());
	Consumer<List<String>> c3=(s)->System.out.println("Start form consumer skill List"+s);
	list.forEach((emp)->{
		c1.accept(emp.getName());
		c1.accept(emp.getLastName());
	});
	
	list.forEach(c2);
	list.forEach((e)->{
		c3.accept(e.getSkills());
	});
}
}
