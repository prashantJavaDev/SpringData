package consumer.latest;

import java.util.List;
import java.util.function.BiConsumer;

import com.intface.Employee;
import com.intface.EmployeeList;

public class BiConsumerTest {
public static void main(String a[]){
	
	List<Employee> list=EmployeeList.getEmpList();
	BiConsumer<String, Integer> c1=(s,i)->System.out.println("name=="+s+" Id="+i );
	BiConsumer<String, List<String>> c2=(s,ls)->System.out.println("name=="+s+" skillLsit="+ls );
	BiConsumer<Employee, List<String>> c3=(e,ls)->System.out.println("Employee=="+e+" skillLsit="+ls );
	list.forEach((e)->{
		c1.accept(e.getName(), e.getEmpID());
		c2.accept(e.getName(),e.getSkills());
	});
	list.forEach((e)->{
		if(e.getEmpID()>2 && e.getSalary()>50000){
			c3.accept(e, e.getSkills());
		}
	});
	
}
}
