
public class Test1 {
	public Test1() {
		// TODO Auto-generated constructor stub
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			throw new NullPointerException();
		}catch(NullPointerException np ){
			System.out.println("in Exception");
		}
	}

}
