import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import com.intface.Employee;
import com.intface.EmployeeList;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		Set<Object> set=new HashSet<>();
//		String s1=new String("a");
//		String s2=new String("a");
//		StringBuffer s3=new StringBuffer("a");
//		StringBuffer s4=new StringBuffer("a");
//		set.add(s1);
//		set.add(s2);
//		set.add(s3);
//		set.add(s4);
//		System.out.println(set.size());
//		
//		Runtime.getRuntime().freeMemory();
		List<Employee> list= EmployeeList.getEmpList();
		
		List<String> lls=list.stream()
		.filter(p->p.getEmpID()>2)
		.map(p->p.getName())
		.collect(Collectors.toList());
		System.out.println("-------------"+lls);
		
		
		Map<String,Long> l1= list.stream()
				.collect(Collectors.groupingBy(Employee::getGender ,Collectors.counting()))
				;
		System.out.println(l1);
		
		list.stream().map(Employee::getSkills).
				flatMap(List::stream).distinct()
				.forEach(System.out::println);
		
		
		Map<String,Double> l3= list.stream()
				.collect(Collectors.groupingBy(Employee::getGender ,Collectors.averagingDouble(Employee::getSalary)))
				;
		System.out.println(l3);
		Optional<Employee> e=list.stream()
		.collect(Collectors.maxBy(Comparator.comparing(Employee:: getSalary)));
	System.out.println(e.isPresent()?e.get():null);
	int a=10;
	Employee e1=new Employee("Pk", "Ka", 1, 30000, Arrays.asList("Java", "DB"),"M");
	Employee e2=new Employee("Pk", "Ka", 1, 30000, Arrays.asList("Java", "DB"),"M");
	String s=new String("abc");
	System.out.println("------------Test");
	System.out.println(e1);
	change(e1);
	System.out.println(e1);
	
	HashMap<Employee, String> map=new HashMap<>();
	map.put(e1, "I m HERE");
//	map.put(e2, "I m  tHERE");
	System.out.println(map.get(new Employee("Pk", "Ka", 1, 30000, Arrays.asList("Java", "DB"),"M")));
//	System.out.println(map.get(e2));
	
Optional p=list.stream().
	collect(Collectors.maxBy(Comparator.comparing(Employee::getSalary)));
	System.out.println("datatat=========="+p.get());
	
	
	}
public static void change(Employee a){
	a.setGender("F")
	;
} 	


}
