package predicate.latest;

import java.util.List;
import java.util.function.BiPredicate;

import com.intface.Employee;
import com.intface.EmployeeList;

public class BiPredicateTest {
public static void main(String a[]){
	List<Employee> list=EmployeeList.getEmpList();
	BiPredicate<String, Integer> p1=(s,i)->s.startsWith("P") && i<5;
	BiPredicate<Float, List<String>> p2=(f,ls)->f>20000 && ls.contains("Java");
	
	list.forEach((e)->{
		if(p1.test(e.getName(), e.getEmpID()))
			System.out.println(e);
		
		if(p2.test(e.getSalary(), e.getSkills()))
	       		System.out.println(e);
		
		System.out.println(e);
	
	});
}
}
