package predicate.latest;

import java.util.List;
import java.util.function.Predicate;

import com.intface.Employee;
import com.intface.EmployeeList;

public class PredicateTest {
public static void main(String a[]){
	List<Employee> list=EmployeeList.getEmpList();
	Predicate<String> p1 = (s)->s.startsWith("P");
	Predicate<List<String>> p2 = (s)->s.contains("Java");
	Predicate<Float> p3 = (f)->f>20000;
	list.forEach((e)->{
		if(p1.test(e.getName()))
			System.out.println(e);
		
		if(p2.test(e.getSkills()))
			System.out.println(e);
		
		if(p3.test(e.getSalary()))
			System.out.println(e);
			
	});
}
}
