package function.latest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;

import com.intface.Employee;
import com.intface.EmployeeList;

public class FunctionTest {
	public static void main(String a[]){
		List<Employee> list=EmployeeList.getEmpList();
		Function<Employee, String> f1=(e)->e.getLastName();
		Function<Employee, List<String>> f2=(e)->e.getSkills();
		Predicate<List<String>>p1=(ls)-> ls.contains("Java");
		Function<List<Employee>, Map<String,Float>> f3=(e)->{
			Map<String,Float> map=new HashMap<>();
			e.forEach((emp)->{
				if(p1.test(emp.getSkills()))
					map.put(emp.getName(), emp.getSalary());
			});
			return map;
		};
//		list.forEach((e)->{
//			 System.out.println( f1.apply(e));
//			 System.out.println( f2.apply(e));
//		});
		 System.out.println(f3.apply(list));
	}

}
